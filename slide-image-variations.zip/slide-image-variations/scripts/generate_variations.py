#!/usr/bin/env python3
"""
Generate multiple image variations for presentation slides using Gemini.

Usage:
    python generate_variations.py --prompt "A futuristic city" --count 6
    python generate_variations.py --prompt "AI brain" --count 8 --aspect-ratio 16:9
"""

import argparse
import os
import sys
import json
from pathlib import Path
from datetime import datetime

try:
    from google import genai
    from google.genai import types
except ImportError:
    print("Error: google-genai package not installed.")
    print("Install with: pip install google-genai")
    sys.exit(1)

try:
    from PIL import Image
    import io
except ImportError:
    print("Error: Pillow package not installed.")
    print("Install with: pip install Pillow")
    sys.exit(1)


def generate_variations(
    prompt: str,
    count: int = 6,
    aspect_ratio: str = "16:9",
    output_dir: str = "assets/variations",
    model: str = "gemini-2.5-flash-preview-05-20"
) -> list[Path]:
    """Generate multiple image variations from a prompt."""

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("Error: GEMINI_API_KEY environment variable not set.")
        sys.exit(1)

    client = genai.Client(api_key=api_key)

    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # Generate timestamp for this batch
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    generated_files = []

    print(f"Generating {count} variations...")
    print(f"Prompt: {prompt}")
    print(f"Aspect ratio: {aspect_ratio}")
    print()

    for i in range(count):
        print(f"  Generating variation {i + 1}/{count}...", end=" ", flush=True)

        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_modalities=["IMAGE", "TEXT"],
                    image_config=types.ImageConfig(
                        aspect_ratio=aspect_ratio,
                    ),
                ),
            )

            # Extract image from response
            for part in response.candidates[0].content.parts:
                if part.inline_data is not None:
                    image_data = part.inline_data.data
                    image = Image.open(io.BytesIO(image_data))

                    # Save with numbered filename
                    filename = f"variation_{timestamp}_{i + 1:02d}.jpg"
                    filepath = output_path / filename
                    image.save(filepath, "JPEG", quality=95)
                    generated_files.append(filepath)
                    print(f"✓ {filename}")
                    break
            else:
                print("✗ No image in response")

        except Exception as e:
            print(f"✗ Error: {e}")

    print()
    print(f"Generated {len(generated_files)} images in {output_path}/")

    return generated_files


def create_gallery_html(
    image_files: list[Path],
    prompt: str,
    output_path: str = "assets/variations/gallery.html"
) -> Path:
    """Create an HTML gallery for selecting among variations."""

    gallery_path = Path(output_path)

    # Build image cards HTML
    image_cards = []
    for i, img_path in enumerate(image_files):
        card = f'''
        <div class="image-card" data-index="{i}" data-filename="{img_path.name}">
            <img src="{img_path.name}" alt="Variation {i + 1}">
            <div class="card-overlay">
                <span class="card-number">{i + 1}</span>
            </div>
            <div class="selected-badge">✓ Selected</div>
        </div>'''
        image_cards.append(card)

    html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Variation Selector</title>
    <style>
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}

        body {{
            font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            padding: 2rem;
            color: #e4e4e7;
        }}

        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}

        header {{
            text-align: center;
            margin-bottom: 2rem;
        }}

        h1 {{
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }}

        .prompt-display {{
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 2rem;
            font-style: italic;
            color: #a1a1aa;
        }}

        .gallery {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }}

        .image-card {{
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 3px solid transparent;
            background: rgba(255, 255, 255, 0.05);
        }}

        .image-card:hover {{
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }}

        .image-card.selected {{
            border-color: #667eea;
            box-shadow: 0 0 30px rgba(102, 126, 234, 0.3);
        }}

        .image-card img {{
            width: 100%;
            height: auto;
            display: block;
        }}

        .card-overlay {{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 50%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }}

        .image-card:hover .card-overlay {{
            opacity: 1;
        }}

        .card-number {{
            position: absolute;
            bottom: 1rem;
            left: 1rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
        }}

        .selected-badge {{
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: #667eea;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.875rem;
            opacity: 0;
            transform: scale(0.8);
            transition: all 0.3s ease;
        }}

        .image-card.selected .selected-badge {{
            opacity: 1;
            transform: scale(1);
        }}

        .feedback-section {{
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }}

        .feedback-section h2 {{
            font-size: 1.25rem;
            margin-bottom: 1rem;
            color: #e4e4e7;
        }}

        textarea {{
            width: 100%;
            min-height: 100px;
            padding: 1rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            background: rgba(0, 0, 0, 0.3);
            color: #e4e4e7;
            font-family: inherit;
            font-size: 1rem;
            resize: vertical;
        }}

        textarea:focus {{
            outline: none;
            border-color: #667eea;
        }}

        .actions {{
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }}

        button {{
            padding: 1rem 2rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .btn-primary {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }}

        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }}

        .btn-primary:disabled {{
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }}

        .btn-secondary {{
            background: rgba(255, 255, 255, 0.1);
            color: #e4e4e7;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }}

        .btn-secondary:hover {{
            background: rgba(255, 255, 255, 0.2);
        }}

        .output {{
            margin-top: 2rem;
            padding: 1rem;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            font-family: 'SF Mono', 'Fira Code', monospace;
            font-size: 0.875rem;
            white-space: pre-wrap;
            display: none;
        }}

        .output.visible {{
            display: block;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Select Your Image Variation</h1>
        </header>

        <div class="prompt-display">
            <strong>Prompt:</strong> {prompt}
        </div>

        <div class="gallery">
            {"".join(image_cards)}
        </div>

        <div class="feedback-section">
            <h2>Feedback for Iteration (optional)</h2>
            <textarea id="feedback" placeholder="Describe what you'd like to change... e.g., 'Make it more vibrant' or 'Add more contrast'"></textarea>
        </div>

        <div class="actions">
            <button class="btn-primary" id="confirmBtn" disabled>Confirm Selection</button>
            <button class="btn-secondary" id="iterateBtn">Generate New Variations with Feedback</button>
        </div>

        <pre class="output" id="output"></pre>
    </div>

    <script>
        let selectedCard = null;
        const cards = document.querySelectorAll('.image-card');
        const confirmBtn = document.getElementById('confirmBtn');
        const iterateBtn = document.getElementById('iterateBtn');
        const feedback = document.getElementById('feedback');
        const output = document.getElementById('output');

        cards.forEach(card => {{
            card.addEventListener('click', () => {{
                // Deselect previous
                if (selectedCard) {{
                    selectedCard.classList.remove('selected');
                }}

                // Select new
                card.classList.add('selected');
                selectedCard = card;
                confirmBtn.disabled = false;
            }});
        }});

        confirmBtn.addEventListener('click', () => {{
            if (!selectedCard) return;

            const selection = {{
                action: 'select',
                filename: selectedCard.dataset.filename,
                index: parseInt(selectedCard.dataset.index),
                feedback: feedback.value.trim()
            }};

            output.textContent = JSON.stringify(selection, null, 2);
            output.classList.add('visible');

            // Copy to clipboard
            navigator.clipboard.writeText(JSON.stringify(selection));
            alert('Selection copied to clipboard! Paste this back to Claude.');
        }});

        iterateBtn.addEventListener('click', () => {{
            const selection = {{
                action: 'iterate',
                filename: selectedCard ? selectedCard.dataset.filename : null,
                index: selectedCard ? parseInt(selectedCard.dataset.index) : null,
                feedback: feedback.value.trim()
            }};

            if (!selection.feedback) {{
                alert('Please provide feedback for iteration.');
                return;
            }}

            output.textContent = JSON.stringify(selection, null, 2);
            output.classList.add('visible');

            // Copy to clipboard
            navigator.clipboard.writeText(JSON.stringify(selection));
            alert('Iteration request copied to clipboard! Paste this back to Claude.');
        }});
    </script>
</body>
</html>'''

    gallery_path.write_text(html_content)
    print(f"Created gallery: {gallery_path}")

    return gallery_path


def main():
    parser = argparse.ArgumentParser(description="Generate image variations for slides")
    parser.add_argument("--prompt", required=True, help="Image generation prompt")
    parser.add_argument("--count", type=int, default=6, help="Number of variations (4-8)")
    parser.add_argument("--aspect-ratio", default="16:9", help="Image aspect ratio")
    parser.add_argument("--output-dir", default="assets/variations", help="Output directory")
    parser.add_argument("--model", default="gemini-2.5-flash-preview-05-20", help="Gemini model")

    args = parser.parse_args()

    # Validate count
    if args.count < 1 or args.count > 10:
        print("Error: Count must be between 1 and 10")
        sys.exit(1)

    # Generate variations
    image_files = generate_variations(
        prompt=args.prompt,
        count=args.count,
        aspect_ratio=args.aspect_ratio,
        output_dir=args.output_dir,
        model=args.model
    )

    if image_files:
        # Create gallery
        gallery_path = create_gallery_html(
            image_files,
            args.prompt,
            output_path=f"{args.output_dir}/gallery.html"
        )

        # Output summary as JSON for Claude to parse
        summary = {
            "images": [str(p) for p in image_files],
            "gallery": str(gallery_path),
            "prompt": args.prompt,
            "count": len(image_files)
        }

        print()
        print("=== SUMMARY ===")
        print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
